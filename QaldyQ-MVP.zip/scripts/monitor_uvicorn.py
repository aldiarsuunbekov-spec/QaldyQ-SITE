#!/usr/bin/env python3
"""Watch QaldyQ on port 8000 and restart Uvicorn when it becomes unhealthy.

Run from the project root after installing requirements:
    python scripts/monitor_uvicorn.py

This is for a local/VM process. In Docker, use the Compose restart policy instead.
"""
from __future__ import annotations

import argparse
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

PROJECT_ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = PROJECT_ROOT / ".work" / "logs"
SUPERVISOR_LOG = LOG_DIR / "uvicorn-supervisor.log"
UVICORN_LOG = LOG_DIR / "uvicorn.log"


def configure_logging() -> logging.Logger:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("foodsaver.supervisor")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

    file_handler = RotatingFileHandler(
        SUPERVISOR_LOG, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    return logger


def port_is_open(port: int, host: str = "127.0.0.1", timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def health_check(port: int, timeout: float = 2.0) -> bool:
    if not port_is_open(port, timeout=timeout):
        return False
    request = Request(
        f"http://127.0.0.1:{port}/api/health",
        headers={"Accept": "application/json", "User-Agent": "QaldyQSupervisor/1.0"},
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                return False
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("status") == "ok"
    except (OSError, HTTPError, URLError, ValueError, json.JSONDecodeError):
        return False


def launch_uvicorn(host: str, port: int, forwarded_allow_ips: str) -> subprocess.Popen:
    command = [
        sys.executable,
        "-m",
        "uvicorn",
        "main:app",
        "--host",
        host,
        "--port",
        str(port),
        "--proxy-headers",
        "--forwarded-allow-ips",
        forwarded_allow_ips,
    ]
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) if os.name == "nt" else 0
    with UVICORN_LOG.open("ab") as output:
        return subprocess.Popen(
            command,
            cwd=PROJECT_ROOT,
            env=env,
            stdout=output,
            stderr=subprocess.STDOUT,
            creationflags=creationflags,
        )


def wait_until_healthy(
    process: subprocess.Popen,
    port: int,
    startup_timeout: float,
) -> bool:
    deadline = time.monotonic() + startup_timeout
    while time.monotonic() < deadline and not _shutdown_requested:
        if process.poll() is not None:
            return False
        if health_check(port):
            return True
        time.sleep(1)
    return False


def stop_child(process: subprocess.Popen, logger: logging.Logger) -> None:
    if process.poll() is not None:
        return
    try:
        if os.name == "nt" and hasattr(signal, "CTRL_BREAK_EVENT"):
            process.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            process.terminate()
        process.wait(timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        logger.warning("Graceful Uvicorn stop timed out; terminating child")
        process.kill()
        process.wait(timeout=5)


_shutdown_requested = False


def request_shutdown(_signum: int, _frame: object) -> None:
    global _shutdown_requested
    _shutdown_requested = True


def supervise(args: argparse.Namespace, logger: logging.Logger) -> None:
    process: subprocess.Popen | None = None
    unhealthy_count = 0
    restart_delay = 2.0
    healthy_since: float | None = None

    logger.info(
        "Supervisor started: port=%s host=%s health=http://127.0.0.1:%s/api/health",
        args.port,
        args.host,
        args.port,
    )
    signal.signal(signal.SIGINT, request_shutdown)
    signal.signal(signal.SIGTERM, request_shutdown)
    try:
        while not _shutdown_requested:
            if process is not None and process.poll() is not None:
                logger.warning("Uvicorn exited with code %s; restarting", process.returncode)
                process = None
                unhealthy_count = 0
                time.sleep(restart_delay)
                restart_delay = min(restart_delay * 2, 60.0)
                continue

            if process is None:
                if health_check(args.port):
                    logger.info("A healthy QaldyQ service is already responding on port %s", args.port)
                    time.sleep(args.interval)
                    continue
                if port_is_open(args.port):
                    logger.error(
                        "Port %s is occupied by a non-healthy service; will not start a duplicate Uvicorn process",
                        args.port,
                    )
                    time.sleep(args.interval)
                    continue

                try:
                    process = launch_uvicorn(args.host, args.port, args.forwarded_allow_ips)
                except OSError:
                    logger.exception("Could not launch Uvicorn")
                    time.sleep(restart_delay)
                    restart_delay = min(restart_delay * 2, 60.0)
                    continue

                logger.info("Started Uvicorn (pid=%s); waiting for readiness", process.pid)
                if wait_until_healthy(process, args.port, args.startup_timeout):
                    logger.info("QaldyQ health check is healthy")
                    unhealthy_count = 0
                    healthy_since = time.monotonic()
                    restart_delay = 2.0
                else:
                    exit_code = process.poll()
                    logger.error(
                        "Uvicorn did not become healthy within %ss (exit=%s)",
                        args.startup_timeout,
                        exit_code,
                    )
                    stop_child(process, logger)
                    process = None
                    time.sleep(restart_delay)
                    restart_delay = min(restart_delay * 2, 60.0)
                continue

            if health_check(args.port):
                unhealthy_count = 0
                if healthy_since is None:
                    healthy_since = time.monotonic()
                elif time.monotonic() - healthy_since >= 60:
                    restart_delay = 2.0
            else:
                unhealthy_count += 1
                logger.warning(
                    "Health check failed (%s/%s); port_open=%s",
                    unhealthy_count,
                    args.unhealthy_checks,
                    port_is_open(args.port),
                )
                if unhealthy_count >= args.unhealthy_checks:
                    logger.error("Uvicorn is unhealthy; restarting the supervised process")
                    stop_child(process, logger)
                    process = None
                    healthy_since = None
                    unhealthy_count = 0
                    time.sleep(restart_delay)
                    restart_delay = min(restart_delay * 2, 60.0)
                    continue

            time.sleep(args.interval)
    except KeyboardInterrupt:
        logger.info("Shutdown requested")
    finally:
        if process is not None and process.poll() is None:
            stop_child(process, logger)
            logger.info("Uvicorn child stopped")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0", help="Uvicorn bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Port to monitor (default: 8000)")
    parser.add_argument("--forwarded-allow-ips", default=os.environ.get("QALDYQ_FORWARDED_ALLOW_IPS", "127.0.0.1"), help="Trusted proxy IPs/CIDRs for X-Forwarded-* (default: 127.0.0.1; never use * on a public host)")
    parser.add_argument("--interval", type=float, default=5.0, help="Seconds between checks (default: 5)")
    parser.add_argument("--startup-timeout", type=float, default=45.0, help="Startup readiness timeout (default: 45)")
    parser.add_argument("--unhealthy-checks", type=int, default=3, help="Consecutive failed checks before restart (default: 3)")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    if args.interval <= 0 or args.startup_timeout <= 0 or args.unhealthy_checks < 1:
        parser.error("interval/startup-timeout must be positive and unhealthy-checks must be >= 1")
    return args


def main() -> None:
    args = parse_args()
    logger = configure_logging()
    supervise(args, logger)


if __name__ == "__main__":
    main()
